package repository;

import java.util.List;

import domain.ProjectTeamBean;

public class ProjectTeamDAOImpl implements ProjectTeamDAO{

	@Override
	public void insertProjectTeam(ProjectTeamBean ProjectTeam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProjectTeamBean> selectAll(ProjectTeamBean ProjectTeam) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProjectTeamBean> selectSome(String word) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProjectTeamBean selectOne(ProjectTeamBean ProjectTeam) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countProjectTeam() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateProjectTeam(ProjectTeamBean ProjectTeam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delteProjectTeam(ProjectTeamBean ProjectTeam) {
		// TODO Auto-generated method stub
		
	}

}
