package enums;

public enum Vendor {
	ORACLE,MYSQL,MARIADB,MSSQL //상수가 안좋은이유 안없어지니까. 
								// 이종류는 4가지 서로 호환가능 
}
