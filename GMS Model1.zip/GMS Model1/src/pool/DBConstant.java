package pool;
//공부를 위해서 남겨둠 static 
public class DBConstant {
	public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String MYSQL_DRIVER = "";
	public static final String MARIADB_DRIVER = "";
	public static final String MSSQL_DRIVER = "";
	public static final String CONNECTION_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String USERNAME = "KAN";
	public static final String PASSWORD = "1253"; //커넥션 속성값과 같음  
	//스태틱은 임포트상관없음
}
