package service;

import java.util.List;

import domain.ProjectTeamBean;

public class ProjectTeamServiceImpl implements ProjectTeamService{

	@Override
	public void createProjectTeam(ProjectTeamBean member) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProjectTeamBean> list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProjectTeamBean> selectSome(String word) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProjectTeamBean selectOne(String word) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countService() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void modifyProjectTeam(ProjectTeamBean member) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProjectTeam(ProjectTeamBean member) {
		// TODO Auto-generated method stub
		
	}

}
